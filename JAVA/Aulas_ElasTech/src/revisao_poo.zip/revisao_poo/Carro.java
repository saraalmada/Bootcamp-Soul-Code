package revisao_poo;

public class Carro extends Veiculo {

	@Override
	public void mover() {
		System.out.println("O carro está se movendo");
	}

}
