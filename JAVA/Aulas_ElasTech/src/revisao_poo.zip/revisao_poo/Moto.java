package revisao_poo;

public class Moto extends Veiculo{

	@Override
	public void mover() {
		System.out.println("A moto está se movendo");
	}
	
}
