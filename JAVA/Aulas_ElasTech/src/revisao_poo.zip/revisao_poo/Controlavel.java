package revisao_poo;

public interface Controlavel {
	public void ligar();
	public void desligar();
}
