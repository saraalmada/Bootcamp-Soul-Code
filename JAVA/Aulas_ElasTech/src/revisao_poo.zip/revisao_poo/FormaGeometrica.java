package revisao_poo;

public abstract class FormaGeometrica {
	public abstract void calcularArea();
} 
