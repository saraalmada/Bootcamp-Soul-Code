package revisao_poo;

public class Veiculo {
	
	public void mover() {
		
	}
}
