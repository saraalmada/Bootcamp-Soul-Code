package revisao_poo;

public class Gerente extends Funcionario {

	@Override
	public double calcularSalario() {
		return 5000;
	}
	
}
