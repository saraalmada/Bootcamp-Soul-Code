package revisao_poo;

public class Estagiario extends Funcionario {
	
	@Override
	public double calcularSalario() {
		return 1200;
	}

}
